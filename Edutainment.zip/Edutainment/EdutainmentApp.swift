//
//  EdutainmentApp.swift
//  Edutainment
//
//  Created by Ellie on 9/10/24.
//

import SwiftUI

@main
struct EdutainmentApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
